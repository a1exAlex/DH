import Foundation

precedencegroup PowerPrecedence { higherThan: MultiplicationPrecedence }
infix operator ^^ : PowerPrecedence
func ^^ (radix: Int, power: Int) -> Int {
    return Int(pow(Double(radix), Double(power)))
}

extension Int {
    
    func isPrime() -> Bool {
        return self > 1 && !(2 ..< self).contains { self % $0 == 0 }
    }
    
    func generateRandomPrime(upperBound: Int = 50) -> Int {
        var eratosthenesSieve = Array.init(repeating: true, count: upperBound+1)
        var primes = [Int]()
        eratosthenesSieve[0] = false
        eratosthenesSieve[1] = false
        for i in 2...upperBound where eratosthenesSieve[i] == true {
            var j = i*i
            while j <= upperBound {
                eratosthenesSieve[j] = false
                j += i
            }
            primes.append(i)
        }
        return primes[Int(arc4random_uniform(UInt32(primes.count)))]
    }
}

struct DHDefaultParameters {
    static let p = 23
    static let g = 5
}

struct DHParameters {
    var p: Int = DHDefaultParameters.p // p = safe prime ()
    var g: Int = DHDefaultParameters.g // g = primitive root modulo of p
    
    init() {
        var _p: Int = 0
        var _q: Int = 0
        
        // We choose p so that p=2q+1, where q is also prime
        while !_p.isPrime() {
            _q = Int().generateRandomPrime()
            _p = (2 * _q) + 1
        }
        p = _p
        
        // Than we look for the smallest possible x until x,x2,xk≢1(modp)
        for x in 1...p where
            x % p != 1
                && (x^^2) % p != 1
                && (x^^_q) % p != 1 {
                    g = x
                    break
        }
        print("Generated DHParameters. P is \(p) (safe prime) and g is \(g) (primitive root modulo of modulus)")
        print("Параметры сгенерированы. P is \(p) (safe prime) and g is \(g) (primitive root modulo of modulus) \n")
    }
}

 class Person {
    
    let commonPublicComponent: DHParameters!
    private let privateSecretKey: Int!
    
    init(commonPublicComponent: DHParameters) {
        self.commonPublicComponent = commonPublicComponent
        self.privateSecretKey = Int(arc4random_uniform(10))
    }
    
    func generatePublicKey() -> Int {
        return commonPublicComponent.g ^^ privateSecretKey % commonPublicComponent.p
    }
    
    func computeComputeCommonSecretKey(peerKey: Int) -> Int {
        return peerKey ^^ privateSecretKey % commonPublicComponent.p
    }
}

let commonPublicComponent = DHParameters()

let alice = Person(commonPublicComponent: commonPublicComponent)
let bob = Person(commonPublicComponent: commonPublicComponent)

print("Alice and Bob agrees to use common public component: \(commonPublicComponent)")
print("Алиса и Боб соглашаются использовать публичный компонент: \(commonPublicComponent) \n")

let alicePublicKey = alice.generatePublicKey()
print("Alice generated public key: \(alicePublicKey)")
print("Алиса сгенерировала открытый ключ: \(alicePublicKey) \n")

let bobPublicKey = bob.generatePublicKey()
print("Bob generated public key: \(bobPublicKey)")
print("Боб сгенерировал открытый ключ: \(bobPublicKey) \n")

let aliceComputedCommonSecretKey = alice.computeComputeCommonSecretKey(peerKey: bobPublicKey)
print("Alice computed common secret key: \(aliceComputedCommonSecretKey)")
print("Алиса вычислила общий секретный ключ: \(aliceComputedCommonSecretKey) \n")

let bobComputedCommonSecretKey = bob.computeComputeCommonSecretKey(peerKey: alicePublicKey)
print("Bob computed common secret key: \(bobComputedCommonSecretKey)")
print("Боб вычислил общий секретный ключ: \(bobComputedCommonSecretKey) \n")


print("Alice's and Bob's computed secret keys are the same? - \(aliceComputedCommonSecretKey == bobComputedCommonSecretKey)")
print("Вычисленные секретные ключи Алисы и Боба одинаковы? - \(aliceComputedCommonSecretKey == bobComputedCommonSecretKey) \n")



